from problem1 import warm_up
warm_up()